//
//  PressureViewController.swift
//  Pressura
//
//  Created by alumno on 27/09/22.
//

import UIKit
import SwiftUI

var sistolica = [Double]()
var diastolica = [Double]()
var pulso = [Double]()

var medida = 0


class PressureViewController: UIViewController {
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {

    return UIInterfaceOrientationMask.portrait

    }
    override var shouldAutorotate: Bool {

    return false

    }

    @IBOutlet weak var tfMedSup: UITextField!
    
    @IBOutlet weak var tfMedInf: UITextField!
    
    @IBOutlet weak var tfPulso: UITextField!
        
    @IBOutlet weak var btSiguiente: UIButton!
    
    @IBOutlet weak var btFin: UIButton!
    
    @IBOutlet weak var segMedidas: UISegmentedControl!
    
    var animo : Double!
    
    var comentario : String = ""
    
    
    @IBOutlet weak var btRegresar: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        sistolica = [Double]()
        diastolica = [Double]()
        pulso = [Double]()
    }
    @IBAction func tapped(_ sender: UITapGestureRecognizer) {
        view.endEditing(true)
    }
    
    func isDouble(_ input: String) -> Bool {
        let doubleRegEx = "^(0|([1-9][0-9]*))(\\.[0-9]+)?$"

        let doublePred = NSPredicate(format:"SELF MATCHES %@", doubleRegEx)
        return doublePred.evaluate(with: input)
    }
    
    
    @IBAction func Regresar(_ sender: UIButton) {
        if let first = presentingViewController, let second = first.presentingViewController{
            first.view.isHidden = true
            second.dismiss(animated: true)
        }
    }
    
    @IBAction func btSiguienteSend(_ sender: UIButton) {
        addToArray()
    }
    

    
    func addToArray()
    {
        if (tfMedSup.text == "." || tfMedInf.text == "."  || tfPulso.text == "." || !isDouble(tfMedSup.text!) || !isDouble(tfMedInf.text!) || !isDouble(tfPulso.text!)){
            let alerts = UIAlertController(title: "Error", message: "Favor de llenar todos los campos con números", preferredStyle: .alert)
            let accion = UIAlertAction(title: "OK", style: .cancel)
            alerts.addAction(accion)
            present(alerts, animated: true)
        } else if (!tfMedSup.text!.isEmpty && !tfMedInf.text!.isEmpty && !tfPulso.text!.isEmpty )
            {
                
                if Double(tfMedSup.text!)! < 0 || Double(tfMedInf.text!)! < 0 {
                    let alerts = UIAlertController(title: "Error", message: "Favor de valores mayores a 0", preferredStyle: .alert)
                    let accion = UIAlertAction(title: "OK", style: .cancel)
                    alerts.addAction(accion)
                    present(alerts, animated: true)
                }  else if (Double(tfMedSup.text!)! <= Double(tfMedInf.text!)! ){
                    let alerts = UIAlertController(title: "Error", message: "Favor de asegurar que la Medida Superior sea mayor a la Medida Inferior", preferredStyle: .alert)
                    let accion = UIAlertAction(title: "OK", style: .cancel)
                    alerts.addAction(accion)
                    present(alerts, animated: true)
                }else{
                    sistolica.append(round(10*(Double("0"+tfMedSup.text!))!)/10)
                    diastolica.append(round(10*(Double("0"+tfMedInf.text!))!)/10)
                    pulso.append(round(10*(Double("0"+tfPulso.text!))!)/10)
                    
                    tfMedSup.text = ""
                    tfMedInf.text = ""
                    tfPulso.text = ""

                    
                    
                    if sistolica.count == 2
                    {
                        btSiguiente.isEnabled = false
                        btFin.isEnabled = true
                    }
                     if sistolica.count < 3
                    {
                        segMedidas.selectedSegmentIndex = 1
                         btFin.isEnabled = true
                        self.performSegue(withIdentifier: "crono", sender: nil)
                    }
                }
            }
            else
            {
                let alerts = UIAlertController(title: "Error", message: "Favor de ingresar ambas medidas", preferredStyle: .alert)
                let accion = UIAlertAction(title: "OK", style: .cancel)
                alerts.addAction(accion)
                present(alerts, animated: true)
        }
    }
    
    
    @IBAction func addToArrayAndExit(_ sender: UIButton) {
        
        if (!tfMedSup.text!.isEmpty && !tfMedInf.text!.isEmpty && !tfPulso.text!.isEmpty)
        {
            if Double(tfMedSup.text!)! < 0 || Double(tfMedInf.text!)! < 0  || Double(tfPulso.text!)! < 0{
                let alerts = UIAlertController(title: "Error", message: "Favor de valores mayores a 0", preferredStyle: .alert)
                let accion = UIAlertAction(title: "OK", style: .cancel)
                alerts.addAction(accion)
                present(alerts, animated: true)
            }  else if (Double(tfMedSup.text!)! <= Double(tfMedInf.text!)! ){
                let alerts = UIAlertController(title: "Error", message: "Favor de asegurar que la Medida Sistólica sea mayor a la Medida Diatólica", preferredStyle: .alert)
                let accion = UIAlertAction(title: "OK", style: .cancel)
                alerts.addAction(accion)
                present(alerts, animated: true)
            }else if (tfMedSup.text == "." || tfMedInf.text == "."  || tfPulso.text == "." || !isDouble(tfMedSup.text!) || !isDouble(tfMedInf.text!) || !isDouble(tfPulso.text!)){
                let alerts = UIAlertController(title: "Error", message: "Favor de llenar todos los campos con números", preferredStyle: .alert)
                let accion = UIAlertAction(title: "OK", style: .cancel)
                alerts.addAction(accion)
                present(alerts, animated: true)
            } else {
                
                sistolica.append(round(10*(Double("0"+tfMedSup.text!))!)/10)
                diastolica.append(round(10*(Double("0"+tfMedInf.text!))!)/10)
                pulso.append(round(10*(Double("0"+tfPulso.text!))!)/10)
                
                tfMedSup.text = ""
                tfMedInf.text = ""
                tfPulso.text = ""
                
                self.performSegue(withIdentifier: "confirmar", sender: nil)
                
            }
        } else if (tfMedSup.text!.isEmpty && tfMedInf.text!.isEmpty && tfPulso.text!.isEmpty && sistolica.count > 0){
            
            self.performSegue(withIdentifier: "confirmar", sender: nil)
            
        } else
        {
            let alerts = UIAlertController(title: "Error", message: "Favor de ingresar todas las medidas", preferredStyle: .alert)
            let accion = UIAlertAction(title: "OK", style: .cancel)
            alerts.addAction(accion)
            present(alerts, animated: true)
    }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(sistolica.count < 3)
        {
            segMedidas.selectedSegmentIndex = sistolica.count
            
        }
        if segue.identifier == "confirmar"{
            let vistaConfirm = segue.destination as! ConfirmViewController

            vistaConfirm.animo = animo
            vistaConfirm.comentario = comentario
            vistaConfirm.diastolica = diastolica
            vistaConfirm.sistolica = sistolica
            vistaConfirm.pulso = pulso
            
        }
      
    }

    
    @IBSegueAction func showDetails(_ coder: NSCoder) -> UIViewController? {
        let timerView = TimerSwiftUI(dismissAction: {
            self.dismiss(animated: true)
        })
        return UIHostingController(coder: coder, rootView: timerView)
    }
    
    func dismissKeyboard()
    {
        view.endEditing(true)
    }
    
    
}
