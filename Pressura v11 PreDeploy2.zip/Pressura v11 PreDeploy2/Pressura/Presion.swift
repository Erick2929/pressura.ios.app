//
//  Presion.swift
//  Pressura
//
//  Created by Alumno on 13/10/22.
//

import UIKit

class Presion: Equatable,Comparable {
    
    var fecha : Date
    
    var medidaSupe : Int
    
    var medidaInfe : Int
    
    init(fecha: Date, medidaSupe : Int, medidaInfe : Int) {
        self.fecha = fecha
        self.medidaSupe = medidaSupe
        self.medidaInfe = medidaInfe
    }
    
    static func < (lhs: Presion, rhs: Presion) -> Bool {
        return lhs.fecha < rhs.fecha
    }
    
    static func == (lhs: Presion, rhs: Presion) -> Bool {
        return lhs.fecha == rhs.fecha
    }
    

}
