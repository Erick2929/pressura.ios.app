//
//  DoctoresViewController.swift
//  Pressura
//
//  Created by alumno on 10/10/22.
//

import UIKit
import FirebaseFirestore

class DoctoresViewController: UIViewController, UITableViewDataSource, UIPopoverPresentationControllerDelegate {
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {

    return UIInterfaceOrientationMask.portrait

    }
    override var shouldAutorotate: Bool {

    return false

    }
    
    
    @IBOutlet weak var btAddDoc: UIButton!
    
    @IBOutlet weak var btBack: UIButton!
    
    @IBOutlet var table: UITableView!
    
    var doctores = UserDefaults.standard.object(forKey: "MyDoc") as! [String]
    var doctoresNombres = UserDefaults.standard.object(forKey: "MyDocNom") as! [String]
    var relacion = UserDefaults.standard.object(forKey: "MyDocRel") as! [Int]
    var documentID = UserDefaults.standard.object(forKey: "MyDocIDs") as! [String]
    

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        table.dataSource = self
        table.register(DoctorTableViewCell.nib(), forCellReuseIdentifier: DoctorTableViewCell.identifier)

        
    }
    
    func adaptivePresentationStyle(for controller: UIPresentationController) -> UIModalPresentationStyle {
        return .none
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print(doctores.count)
        return doctores.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let celdas = tableView.dequeueReusableCell(withIdentifier: DoctorTableViewCell.identifier) as! DoctorTableViewCell
        celdas.configue(title: doctores[indexPath.row],title2: doctoresNombres[indexPath.row], relacion: relacion[indexPath.row], row: indexPath.row)
        celdas.delegate = self
        return celdas
    }
    
    
    @IBAction func goBack(_ sender: UIButton)
    {
        self.dismiss(animated: true, completion: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        let vistaPopover = segue.destination as! PopOverViewController
        vistaPopover.popoverPresentationController?.delegate = self
    }
    
    func reloadTable() {
        
        var doct = [String]()
        var doctNomb = [String]()
        var rela = [Int]()
        var doctID = [String]()
        
    
            let db = Firestore.firestore()
            
            db.collection("PacienteConDoctores").whereField("IDPaciente", isEqualTo: UserDefaults.standard.string(forKey: "usuario")!).getDocuments(){ [self]
                (QuerySnapshot, err) in
                if let err = err{
                    print("Error getting documents: \(err)")
                }else{
                    guard let _ = QuerySnapshot else{
                        print("Unknown Error")
                        return
                    }
                    for document in QuerySnapshot!.documents{
                        let data = document.data()
                        let IDDoc = data["IDDoctor"] as? String
                        let NomPac = data["NombreDoctor"] as? String
                        let Rela = data["Relacion"] as? Int
                        let DocumentID = document.documentID as String
                        doct.append(IDDoc!)
                        doctNomb.append(NomPac!)
                        rela.append(Rela!)
                        doctID.append(DocumentID)
                        
                        
                    }
                    doctores = doct
                    doctoresNombres = doctNomb
                    relacion = rela
                    documentID = doctID
                    table.reloadData()

                    
                }
                
            }
        }
}

extension DoctoresViewController : DoctorTableViewCellDeligate{
    func didTapCancel(with row: Int) {
        let alerts = UIAlertController(title: "Alerta", message: "¿Estas seguro de borrar el correo \(doctores[row])", preferredStyle: .alert)
        let accion = UIAlertAction(title: "Si", style: .default) { action in
            let db = Firestore.firestore()
            db.collection("PacienteConDoctores").document(self.documentID[row]).delete() {
                err in
                if let err = err {
                    print("Error removing document: \(err)")
                }else{
                    print("Document Successfuly Removed")
                    self.reloadTable()
                }
            }
        }
        let cancelar = UIAlertAction(title: "No", style: .cancel)
        
        alerts.addAction(cancelar)
        alerts.addAction(accion)
        present(alerts, animated: true)
    }
    
    func didTapAccept(with row: Int) {
        let alerts = UIAlertController(title: "Alerta", message: "¿Estas seguro de acceptar compartir tu información con \(doctoresNombres[row])", preferredStyle: .alert)
        let accion = UIAlertAction(title: "Si", style: .default) { [self] action in
            let db = Firestore.firestore()
            db.collection("PacienteConDoctores").document(documentID[row]).updateData([
                "IDDoctor": doctores[row],
                "IDPaciente": UserDefaults.standard.string(forKey: "usuario"),
                "NombreDoctor" : doctoresNombres[row],
                "NombrePaciente" : UserDefaults.standard.string(forKey: "nombre"),
                "Relacion" : 3
            ]){err in
                if let err = err {
                    print("Error update document: \(err)")
                }else{
                    self.reloadTable()
                }
            
            }
        }
        let cancelar = UIAlertAction(title: "No", style: .cancel)
        
        alerts.addAction(cancelar)
        alerts.addAction(accion)
        present(alerts, animated: true)
    }
    
    
}
