//
//  RelaxViewController.swift
//  Pressura
//
//  Created by alumno on 27/09/22.
//

import UIKit

class RelaxViewController: UIViewController, UIPopoverPresentationControllerDelegate {
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {

    return UIInterfaceOrientationMask.portrait

    }
    
    override var shouldAutorotate: Bool {

    return false

    }

    
    @IBOutlet weak var slGBState: UISlider!
    
    
    @IBOutlet weak var btBack: UIButton!
    
    @IBOutlet weak var tfComentarios: UITextField!
    
    @IBOutlet weak var labelComentarios: UILabel!
    
    @IBAction func tapped(_ sender: UITapGestureRecognizer) {
        view.endEditing(true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func back(_ sender: UIButton)
    {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func cambioValor(_ sender: Any) {
        if(slGBState.value > 0.9){
            tfComentarios.isHidden = true
            labelComentarios.isHidden = true
            tfComentarios.text = ""
        } else {
            tfComentarios.isHidden = false
            labelComentarios.isHidden = false
        }
    }
    
    func alarma(mensaje:String)
        {
        let alerts = UIAlertController(title: "Error", message: mensaje, preferredStyle: .alert)
        let accion = UIAlertAction(title: "OK", style: .cancel)
        alerts.addAction(accion)
        present(alerts, animated: true)
        }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
            if(segue.identifier == "tomar"){
                let vistaPressure = segue.destination as! PressureViewController
                vistaPressure.animo = Double(slGBState.value)
                vistaPressure.comentario = String(tfComentarios.text!)
            }else{
                let vistaPopover = segue.destination as! AclaracionesViewController
                vistaPopover.popoverPresentationController?.delegate = self
            
        }
    }
    func adaptivePresentationStyle(for controller: UIPresentationController) -> UIModalPresentationStyle {
        return .none
    }

    
}
