//
//  TimerSwiftUI.swift
//  Pressura
//
//  Created by Alumno on 15/10/22.
//

import SwiftUI

struct TimerSwiftUI: View {
    
    
    
    @StateObject private var vm = ViewModel()
    private let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    private let width: Double = 250
    
    var dismissAction: (() -> Void)
    
    
    var body: some View {
        VStack{
            Text("\(vm.time)")
                .font(.system(size: 70, weight: .medium, design: .rounded))
                .padding()
                .frame(width: width)
                .background(.thinMaterial)
                .cornerRadius(20)
                .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.init(red: 0.145 , green: 0.596, blue: 0.569), lineWidth: 4))
                .alert("Su tiempo ha terminado!", isPresented: $vm.showingAlert) {
                Button("Continuar",role: .cancel, action: dismissAction)
                }.onAppear{
                    self.vm.start(minutes: vm.minutes)
                }
                .padding()
            Button("Finalizar"){
                dismissAction()
            }
            .tint(Color.init(red: 0.145 , green: 0.596, blue: 0.569))
            
        }.onReceive(timer) { _ in
            vm.updateCountdown()
        }
    }
}

/*struct TimerSwiftUI_Previews: PreviewProvider {
    static var previews: some View {
        TimerSwiftUI(dismissAction: )
    }
}
*/
