//
//  PacienteConDoctor.swift
//  Pressura
//
//  Created by Alumno on 11/10/22.
//

import UIKit

class PacienteConDoctor: NSObject {
    var IDDoctor : String
    var IDPaciente : String
    var Relacion : Int
    
    init(IDDoctor:String, IDPaciente:String, Relacion:Int) {
        self.IDDoctor = IDDoctor
        self.IDPaciente = IDPaciente
        self.Relacion = Relacion
    }
}
