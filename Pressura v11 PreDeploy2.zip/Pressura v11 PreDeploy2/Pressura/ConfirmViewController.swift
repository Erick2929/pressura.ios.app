//
//  ConfirmViewController.swift
//  Pressura
//
//  Created by alumno on 28/09/22.
//

import UIKit
import Firebase

class ConfirmViewController: UIViewController {
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {

    return UIInterfaceOrientationMask.portrait

    }
    override var shouldAutorotate: Bool {

    return false

    }
    
    @IBOutlet weak var tfEstadoCorp: UITextField!
        
    @IBOutlet weak var tfMed1Sup: UITextField!
    
    @IBOutlet weak var tfMed1Inf: UITextField!
    
    @IBOutlet weak var tfPulso1: UITextField!
    
    @IBOutlet weak var tfMed2Sup: UITextField!
    
    @IBOutlet weak var tfMed2Inf: UITextField!
    
    @IBOutlet weak var tfPulso2: UITextField!
    
    @IBOutlet weak var tfMed3Sup: UITextField!
    
    @IBOutlet weak var tfMed3Inf: UITextField!
    
    @IBOutlet weak var tfPulso3: UITextField!
    
    @IBOutlet weak var btEnviarMed: UIButton!
    
    var sistolica : [Double]!
    var diastolica : [Double]!
    var pulso : [Double]!
    
    var animo : Double!
    var comentario : String = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tfEstadoCorp.text = "\(ceil(animo*10))"
        tfMed1Sup.text = "\(sistolica[0])"
        tfMed1Inf.text = "\(diastolica[0])"
        tfPulso1.text = "\(pulso[0])"

        if sistolica.count == 2 {
            tfMed2Sup.text = "\(sistolica[1])"
            tfMed2Inf.text = "\(diastolica[1])"
            tfPulso2.text = "\(pulso[1])"

        } else if sistolica.count == 3 {
            tfMed2Sup.text = "\(sistolica[1])"
            tfMed2Inf.text = "\(diastolica[1])"
            tfPulso2.text = "\(pulso[1])"
            tfMed3Sup.text = "\(sistolica[2])"
            tfMed3Inf.text = "\(diastolica[2])"
            tfPulso3.text = "\(pulso[2])"

        }
    }
    
    
    @IBAction func enviarDatos(_ sender: UIButton) {
        //enviar datos a base de datos
        
        let db = Firestore.firestore()
        
        let now = Date()
        let stamp = Timestamp(date: now)
                
        
        
        var promedioSupe : Double = 0
        var promedioInfe : Double = 0
        var promedioPulso : Double = 0

        
        print("here")
        
        for valSupe in sistolica {
            promedioSupe = promedioSupe + valSupe
        }
        
        print("there")

        
        for valInfe in diastolica {
            promedioInfe = promedioInfe + valInfe
        }
        
        print("where")
        
        for valPul in pulso {
            promedioPulso = promedioPulso + valPul
        }

        
        promedioInfe = promedioInfe / Double(diastolica.count)
        
        promedioSupe = promedioSupe / Double(sistolica.count)
        
        promedioPulso = promedioPulso / Double(pulso.count)
        
        var docData: [String: Any]
        
        if sistolica.count == 2 {
            docData = [
                "EstadoEmocional": (ceil(animo*100)),
                "Comentario": comentario,
                "Fecha": stamp,
                "IDPaciente": UserDefaults.standard.string(forKey: "usuario")!,
                "MedidaInferior": promedioInfe,
                "MedidaSuperior": promedioSupe,
                "MedidaPulso":promedioPulso,
                "MedidaInferior1": diastolica[0],
                "MedidaSuperior1": sistolica[0],
                "MedidaPulso1":pulso[0],
                "MedidaInferior2": diastolica[1],
                "MedidaSuperior2": sistolica[1],
                "MedidaPulso2":pulso[1],
                "MedidaInferior3": "-",
                "MedidaSuperior3": "-",
                "MedidaPulso3":"-",
            ]

        } else if sistolica.count == 3 {
            docData = [
                "EstadoEmocional": (ceil(animo*100)),
                "Comentario": comentario,
                "Fecha": stamp,
                "IDPaciente": UserDefaults.standard.string(forKey: "usuario")!,
                "MedidaInferior": promedioInfe,
                "MedidaSuperior": promedioSupe,
                "MedidaPulso":promedioPulso,
                "MedidaInferior1": diastolica[0],
                "MedidaSuperior1": sistolica[0],
                "MedidaPulso1":pulso[0],
                "MedidaInferior2": diastolica[1],
                "MedidaSuperior2": sistolica[1],
                "MedidaPulso2":pulso[1],
                "MedidaInferior3": diastolica[2],
                "MedidaSuperior3": sistolica[2],
                "MedidaPulso3":pulso[2],
            ]

        } else {
            docData = [
                "EstadoEmocional": (ceil(animo*100)),
                "Comentario": comentario,
                "Fecha": stamp,
                "IDPaciente": UserDefaults.standard.string(forKey: "usuario")!,
                "MedidaInferior": promedioInfe,
                "MedidaSuperior": promedioSupe,
                "MedidaPulso":promedioPulso,
                "MedidaInferior1": diastolica[0],
                "MedidaSuperior1": sistolica[0],
                "MedidaPulso1":pulso[0],
                "MedidaInferior2": "-",
                "MedidaSuperior2": "-",
                "MedidaPulso2":"-",
                "MedidaInferior3": "-",
                "MedidaSuperior3": "-",
                "MedidaPulso3":"-",
            ]
        }
        
        
                
        var ref: DocumentReference? = nil
        ref = db.collection("Presion").addDocument(data: docData) { err in
            if let err = err {
                print("Error adding document: \(err)")
            } else {
                print("Document added with ID: \(ref!.documentID)")
                if let first = self.presentingViewController, let second = first.presentingViewController, let third = second.presentingViewController{
                    first.view.isHidden = true
                    second.view.isHidden = true
                    third.dismiss(animated: true)
                }
            }
        }
        
        
    }
    
    func desplegarDatos()
    {
        //Desplegar datos en los text fields respectivos
    }
    
    @IBAction func reiniciarToma(_ sender: UIButton) {
        let alerts = UIAlertController(title: "Confirmado", message: "¿Estás seguro que quieres reiniciar la toma?", preferredStyle: .alert)
        let accion = UIAlertAction(title: "Si", style: .default) { [self] action in
            reiniciar()
        }
        
        let cancelar = UIAlertAction(title: "No", style: .cancel)
        alerts.addAction(cancelar)
        alerts.addAction(accion)

        present(alerts, animated: true)
        
    }
    
    func reiniciar(){
        if let first = presentingViewController, let second = first.presentingViewController{
            first.view.isHidden = true
            second.dismiss(animated: true)
        }
    }
    
}
