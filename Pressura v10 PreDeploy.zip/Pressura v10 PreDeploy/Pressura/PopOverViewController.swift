//
//  PopOverViewController.swift
//  Pressura
//
//  Created by alumno on 10/10/22.
//

import UIKit
import Firebase

class PopOverViewController: UIViewController {

    @IBOutlet weak var tfDocEmail: UITextField!
    @IBOutlet weak var btSend: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        preferredContentSize = CGSize(width: 305, height: 175)
        
    }
    
    func alarma(mensaje:String)
        {
        let alerts = UIAlertController(title: "Error", message: mensaje, preferredStyle: .alert)
        let accion = UIAlertAction(title: "OK", style: .cancel)
        alerts.addAction(accion)
        present(alerts, animated: true)
        }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {

    return UIInterfaceOrientationMask.portrait

    }
    override var shouldAutorotate: Bool {

    return false

    }
    
    @IBAction func sendEmail(_ sender: UIButton)
    {
        //Enviar correo de doc
        
        
        
        
        if !isValidEmail(tfDocEmail.text!){
            alarma(mensaje: "Favor de ingresar un correo valido")
        }else{
            var  doctores = UserDefaults.standard.object(forKey: "MyDoc") as! [String]
            if doctores.contains(String(tfDocEmail.text!).lowercased()){
                alarma(mensaje: "Solicitud ya enviada o ya realizada.")

            }else{
                
                
                let db = Firestore.firestore()
                
                
                let docData: [String: Any] = [
                    "IDDoctor": String(tfDocEmail.text!).lowercased(),
                    "IDPaciente": UserDefaults.standard.string(forKey: "usuario") as Any,
                    "NombreDoctor" : "",
                    "NombrePaciente" : UserDefaults.standard.string(forKey: "nombre") as Any,
                    "Relacion" : 1
                ]
                
                var ref: DocumentReference? = nil
                ref = db.collection("PacienteConDoctores").addDocument(data: docData) { err in
                    if let err = err {
                        print("Error adding document: \(err)")
                    } else {
                        doctores.append(String(self.tfDocEmail.text!).lowercased())
                        UserDefaults.standard.setValue(doctores, forKey: "MyDoc")
                        print("Document added with ID: \(ref!.documentID)")
                        self.finalizar()
                    }
                }
            }
        }
    }
    
    func isValidEmail(_ email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"

        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: email)
    }
    
    func finalizar() {
        let abajo = self.presentingViewController as! DoctoresViewController
        abajo.reloadTable()
        self.dismiss(animated: true)
    }
    
}
