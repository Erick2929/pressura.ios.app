//
//  TimerViewController.swift
//  Pressura
//
//  Created by alumno on 27/09/22.
//

import UIKit

class TimerViewController: UIViewController {
    
    var count = 60
    
    @IBOutlet weak var lbTimer: UILabel!
    
    @IBOutlet weak var btSiguiente: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        /*
        var timer = Timer.scheduledTimer(timeInterval: 0.4, target: self, selector: #selector(UIMenuController.update), userInfo: nil, repeats: true)
         */
        
    }
   
    @IBAction func regresar(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
    
/*
   func update()
    {
        if(count > 0)
        {
            lbTimer.text = String(count -= count)
        }
    }
*/
}
