//
//  ProfileViewController.swift
//  Pressura
//
//  Created by alumno on 01/10/22.
//

import UIKit
import Firebase

class ProfileViewController: UIViewController {
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {

    return UIInterfaceOrientationMask.portrait

    }
    override var shouldAutorotate: Bool {

    return false

    }

    @IBOutlet weak var tfName: UITextField!
    
    @IBOutlet weak var dpDateofBirth: UIDatePicker!
    
    @IBOutlet weak var Sexo: UISegmentedControl!
        
    @IBOutlet weak var tfHeight: UITextField!
    
    @IBOutlet weak var tfWeight: UITextField!
        
    @IBOutlet weak var tfEmail: UITextField!
        
    @IBOutlet weak var btEdit: UIButton!
    
    @IBOutlet weak var btBack: UIButton!
    
    var idDoc : String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getData()

    }
    
    func isDouble(_ input: String) -> Bool {
        let doubleRegEx = "^(0|([1-9][0-9]*))(\\.[0-9]+)?$"

        let doublePred = NSPredicate(format:"SELF MATCHES %@", doubleRegEx)
        return doublePred.evaluate(with: input)
    }
    
    @IBAction func back(_ sender: UIButton)
    {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func tapped(_ sender: UITapGestureRecognizer) {
        view.endEditing(true)
    }
    
    @IBAction func editAndSave(_ sender: UIButton)
    {
        if (!tfHeight.text!.isEmpty && !tfWeight.text!.isEmpty && !tfName.text!.isEmpty && !(tfHeight.text == "." || tfWeight.text == "." || !isDouble(tfHeight.text!) || !isDouble(tfWeight.text!) || !isValidName(tfName.text!)))
        {
            editProfile()
            let nuevoMensaje = presentingViewController as! MainMenuViewController
            nuevoMensaje.actulizarMensaje(mensaje:  String(self.tfName.text!))

        }else if (tfHeight.text == "." || tfWeight.text == "." || !isDouble(tfHeight.text!) || !isDouble(tfWeight.text!) ){
            let alerts = UIAlertController(title: "Error", message: "Favor de llenar campos Altura y Peso con números", preferredStyle: .alert)
            let accion = UIAlertAction(title: "OK", style: .cancel)
            alerts.addAction(accion)
            present(alerts, animated: true)
        }else if !isValidName(tfName.text!){
            let alerts = UIAlertController(title: "Error", message: "Favor de ingresar un nombre valido sin acentos", preferredStyle: .alert)
            let accion = UIAlertAction(title: "OK", style: .cancel)
            alerts.addAction(accion)
            present(alerts, animated: true)
        }
            
        else{
            let alerts = UIAlertController(title: "Error", message: "Favor de llenar todos los campos", preferredStyle: .alert)
            let accion = UIAlertAction(title: "OK", style: .cancel)
            alerts.addAction(accion)
            present(alerts, animated: true)

        }
        
    }
    
    func editProfile()
    {
        //al picar boton entrar en modo editar y al picarle de nuevo, guardar cambios
        let db = Firestore.firestore()
        db.collection("Paciente").document(idDoc!).updateData([
            "Altura": round(10*(Double("0"+tfHeight.text!))!)/10 ,
            "CorreoElectronico": String(tfEmail.text!),
            "FechaNacimiento": dpDateofBirth.date,
            "IDPaciente":  String(tfEmail.text!),
            "Nombre": String(self.tfName.text!),
            "Peso": round(10*(Double("0"+tfWeight.text!))!)/10,
            "Sexo": Sexo.selectedSegmentIndex
        ]){err in
            if let err = err {
                print("Error update document: \(err)")
            }else{
                UserDefaults.standard.setValue(String(self.tfName.text!), forKey: "nombre")
                self.dismiss(animated: true)
            }
        }
    }
 
    func getData() {
        var information : [String:Any]?
        let db = Firestore.firestore()
        
        db.collection("Paciente").whereField("IDPaciente", isEqualTo: UserDefaults.standard.string(forKey: "usuario")!).getDocuments(){ [self]
            (QuerySnapshot, err) in
            if let err = err{
                print("Error getting documents: \(err)")
            }else{
                information = QuerySnapshot!.documents.first?.data()
                print(information!)
                idDoc = (QuerySnapshot?.documents.first!.documentID)!
                self.setData(data: information)
            }
        }
    }
    
    func isValidName(_ nombre: String) -> Bool {
        let nameRegEx = "^[\\p{L}'-][\\p{L}' -]{1,40}$"

        let namePred = NSPredicate(format:"SELF MATCHES %@", nameRegEx)
        return namePred.evaluate(with: nombre)
    }
    
    func setData(data : [String:Any]? ) {
        tfName.text = data!["Nombre"] as? String
        
        let ts = (data!["FechaNacimiento"] as? Timestamp)!
        
        let aDate = ts.dateValue()
        
        dpDateofBirth.setDate(aDate, animated: false)
        
        Sexo.selectedSegmentIndex = (data!["Sexo"] as? Int)!
        
        tfHeight.text = String((data!["Altura"] as? Double)!)
        
        tfWeight.text = String((data!["Peso"] as? Double)!)
                
        tfEmail.text = data!["IDPaciente"] as? String

    }
}
